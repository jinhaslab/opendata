// app.js
$(document).ready(function() {
  console.log("Document ready and script loaded."); // Debug log

  $(document).on('change', '.my-radio-button', function() {
    var name = $(this).attr('name');
    var value = $(this).val();
    console.log("Radio button changed:", name, value); // Debug log
    Shiny.setInputValue(name, value);
  });
});